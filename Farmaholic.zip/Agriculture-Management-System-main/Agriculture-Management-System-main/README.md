# Agriculture Management
 A web based DBMS mini-project for agriculture details such as crops, fertilizers & soil.
