<?php
  $db = mysqli_connect('localhost','root','','agri') or die(mysqli_error($connection));
?>